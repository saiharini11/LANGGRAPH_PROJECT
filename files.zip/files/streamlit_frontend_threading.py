import streamlit as st
from langgraph_backend import chatbot
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
import uuid
from langchain_openai import ChatOpenAI

# ---------------------------- Utility functions -------------------------------
def generate_thread_id():
# To generate a dynamic random thread id
    thread_id = uuid.uuid4()
    return thread_id

def reset_chat():
    thread_id = generate_thread_id()
    st.session_state['thread_id'] = thread_id
    st.session_state['thread_title'] = "New Chat"
    
    st.session_state['message_history'] = []

def add_thread(thread_id,thread_title):
    if thread_id not in st.session_state['chat_threads']:
        st.session_state['chat_threads'].append({thread_id:thread_title})
        
def load_conversation(thread_id):
    # Returns messages of a particular thread_id
    CONFIG = {'configurable': {'thread_id' : thread_id}}
    state = chatbot.get_state(config=CONFIG)
    if not state.values or 'messages' not in state.values:
        return []
    return state.values['messages']

def generate_title(user_message):
    model = ChatOpenAI()
    prompt = f"Give a very short 3 to 5 word title for this conversation : \n {user_message}"

    result = model.invoke(prompt)
    title = result.content.strip()
    return title



# ------------------ Session setup -----------------------------------
if 'message_history' not in st.session_state:
    st.session_state['message_history'] =[]

if 'thread_id' not in st.session_state:
    st.session_state['thread_id'] = generate_thread_id()

if 'thread_title' not in st.session_state:
    st.session_state['thread_title'] = "New Chat"

if 'chat_threads' not in st.session_state:
    st.session_state['chat_threads'] = []





# ------------------  Sidebar UI ------------------------------
st.sidebar.title('LangGraph Chatbot')
if st.sidebar.button('New Chat'):
    reset_chat()
st.sidebar.header('My Conversations')
for thread in st.session_state['chat_threads'][::-1]:
    thread_id = list(thread.keys())[0]
    title=thread[thread_id]
    if st.sidebar.button(title, key = str(thread_id)):
        st.session_state['thread_id'] = thread_id
        messages = load_conversation(thread_id)
        temp_messages = []
        for msg in messages:
            if isinstance(msg,HumanMessage):
                role='user'
            else:
                role='assistant'
            temp_messages.append({'role':role, 'content':msg.content })
        st.session_state['message_history'] = temp_messages


# message_history - format
# [{'role': 'user', 'content='Hi'},
# {'role': 'assistant', 'content='Hello'}]
# ------------------------------------  Main UI -------------------------------------

# Loading the conversation history
for message in st.session_state['message_history']:
    with st.chat_message(message['role']):
        st.text(message['content'])

user_input=st.chat_input('Type here')
if user_input:
    st.session_state['message_history'].append({'role':'user','content':user_input})
    if(st.session_state['thread_title']=="New Chat"):
        title=generate_title(user_input)
        st.session_state['thread_title'] =  title
        #st.session_state['chat_threads'][-1][st.session_state['thread_id']]=title
        add_thread(st.session_state['thread_id'],st.session_state['thread_title'] )
    with st.chat_message('user'):
        st.text(user_input)
    CONFIG = {'configurable': {'thread_id' : st.session_state['thread_id']}}
    with st.chat_message('assistant'):
        # Streaming
        ai_message = st.write_stream(
            message_chunk.content for message_chunk,metadata in chatbot.stream(
                {'messages': [HumanMessage(content=user_input)]},
                config=CONFIG,stream_mode='messages'
            )
        )
    st.session_state['message_history'].append({'role':'assistant','content':ai_message})
    

