from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph.message import add_messages
from langchain_huggingface import ChatHuggingFace,HuggingFaceEndpoint
from dotenv import load_dotenv
from langgraph.checkpoint.memory import MemorySaver

load_dotenv()

model = ChatOpenAI()

class ChatState(TypedDict):
    # Reducer function add - To append
    messages: Annotated[list[BaseMessage],add_messages]

def chat_node(state:ChatState):
    # Take user query from state
    messages = state['messages']
    # Send to llm
    response = model.invoke(messages)
    # response store in state
    return {'messages':[response]}

checkpointer=MemorySaver()
# Define graph
graph = StateGraph(ChatState)

# Add nodes
graph.add_node('chat_node',chat_node)

# Add edges
graph.add_edge(START,'chat_node')
graph.add_edge('chat_node',END)

chatbot = graph.compile(checkpointer=checkpointer)


#chatbot = graph.compile()

# from IPython.display import Image
# Image(chatbot.get_graph().draw_mermaid_png())

# thread_id='1'
# while True:
#     user_message = input("Type here: ")
#     print("User:",user_message)
#     if user_message.strip().lower() in ['exit','quit','bye']:
#         break
#     config={'configurable': {'thread_id' : thread_id}}
#     result = chatbot.invoke({'messages':HumanMessage(content=user_message)},config=config)
#     ai_message=result['messages'][-1]
#     print('AI: ',ai_message.content)

# # Full conversation history is stored
# print(chatbot.get_state(config=config))