from fastmcp import FastMCP
import sqlite3
from datetime import datetime

# =========================================================
# MCP SERVER INITIALIZATION
# =========================================================

mcp = FastMCP("ExpenseTracker")

DB = "expenses.db"

# =========================================================
# DATABASE INITIALIZATION
# =========================================================

def init_db():
    conn = sqlite3.connect(DB)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        note TEXT,
        created_at TEXT
    )
    """)
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# =========================================================
# TOOL 1 : ADD EXPENSE
# =========================================================

@mcp.tool()
def add_expense(
    amount: float,
    category: str,
    note: str = ""
):
    """
    Add a new expense transaction.

    Use this tool whenever the user mentions:
    - spending money
    - buying something
    - making a payment
    - recording expenses
    - purchases
    - transactions

    Examples:
    - "I spent 500 on food"
    - "Add 1200 rupees travel expense"
    - "I bought groceries for 850"

    Args:
        amount:
            Amount spent by the user.

        category:
            Expense category such as:
            food, grocery, travel, shopping,
            rent, medical, entertainment, bills.

        note:
            Optional extra description about the expense.

    Returns:
        Confirmation message after saving expense.
    """

    conn = sqlite3.connect(DB)

    conn.execute(
        """
        INSERT INTO expenses
        (amount, category, note, created_at)

        VALUES (?, ?, ?, ?)
        """,
        (
            amount,
            category,
            note,
            datetime.now().isoformat()
        )
    )

    conn.commit()
    conn.close()

    return (
        f"Expense added successfully.\n"
        f"Amount: {amount}\n"
        f"Category: {category}\n"
        f"Note: {note}"
    )

# =========================================================
# TOOL 2 : TOTAL EXPENSES
# =========================================================

@mcp.tool()
def get_total_expense():
    """
    Get total amount spent across all expenses.

    Use this tool when the user asks:
    - total expenses
    - total spending
    - how much money spent
    - expense summary
    - overall expenses

    Examples:
    - "What is my total expense?"
    - "How much did I spend?"
    - "Show total spending"

    Returns:
        Total amount spent by the user.
    """

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute(
        "SELECT SUM(amount) FROM expenses"
    )

    total = cur.fetchone()[0]

    conn.close()

    if total is None:
        total = 0

    return {
        "total_expense": round(total, 2)
    }

# =========================================================
# TOOL 3 : LIST RECENT EXPENSES
# =========================================================

@mcp.tool()
def list_expenses(limit: int = 10):
    """
    Retrieve recent expense records.

    Use this tool when the user asks:
    - show expenses
    - expense history
    - recent transactions
    - latest expenses
    - spending records

    Examples:
    - "Show my recent expenses"
    - "List transactions"
    - "Display last 5 expenses"

    Args:
        limit:
            Number of recent expense records to retrieve.

    Returns:
        List of recent expenses ordered from latest to oldest.
    """

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute(
        """
        SELECT
            amount,
            category,
            note,
            created_at

        FROM expenses

        ORDER BY id DESC

        LIMIT ?
        """,
        (limit,)
    )

    rows = cur.fetchall()

    conn.close()

    expenses = []

    for row in rows:

        expenses.append(
            {
                "amount": row[0],
                "category": row[1],
                "note": row[2],
                "created_at": row[3]
            }
        )

    return expenses

# =========================================================
# TOOL 4 : CATEGORY WISE SUMMARY
# =========================================================

@mcp.tool()
def get_category_summary():
    """
    Get expense totals grouped by category.

    Use this tool when user asks:
    - spending by category
    - category summary
    - food vs travel expenses
    - expense breakdown
    - spending analysis

    Examples:
    - "Show category wise expenses"
    - "How much did I spend on food?"
    - "Expense breakdown"

    Returns:
        Expense totals grouped by category.
    """

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute(
        """
        SELECT
            category,
            SUM(amount)

        FROM expenses

        GROUP BY category

        ORDER BY SUM(amount) DESC
        """
    )

    rows = cur.fetchall()

    conn.close()

    summary = []

    for row in rows:

        summary.append(
            {
                "category": row[0],
                "total": round(row[1], 2)
            }
        )

    return summary

# =========================================================
# TOOL 5 : DELETE ALL EXPENSES
# =========================================================

@mcp.tool()
def clear_all_expenses():
    """
    Delete all expense records from the database.

    Use this tool ONLY when user explicitly asks:
    - clear expenses
    - delete all expenses
    - reset expense tracker
    - remove all transactions

    WARNING:
    This permanently deletes all stored expenses.

    Returns:
        Confirmation message.
    """

    conn = sqlite3.connect(DB)

    conn.execute(
        "DELETE FROM expenses"
    )

    conn.commit()
    conn.close()

    return "All expenses deleted successfully."

# =========================================================
# START MCP SERVER
# =========================================================

if __name__ == "__main__":

    print("Expense Tracker MCP Server Running...")

    mcp.run()