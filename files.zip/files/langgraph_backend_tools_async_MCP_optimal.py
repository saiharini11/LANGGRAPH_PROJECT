from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Annotated
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph.message import add_messages
#from langchain_huggingface import ChatHuggingFace,HuggingFaceEndpoint
from dotenv import load_dotenv
from langgraph.checkpoint.sqlite import SqliteSaver
import sqlite3
from langgraph.prebuilt import ToolNode,tools_condition
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_core.tools import tool
import asyncio
import requests
import random
import aiosqlite
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from Basic_Rag import RAGPDF
import httpx
from langchain_core.tools import StructuredTool
import uuid
from langchain_mcp_adapters.client import MultiServerMCPClient


# -------------------------------------------------------------------
# Custom aiosqlite connection wrapper
# Adds is_alive() expected by newer LangGraph versions
# -------------------------------------------------------------------

class SafeAioSqliteConnection:

    def __init__(self, conn):
        self._conn = conn

    def is_alive(self):
        return True

    def __getattr__(self, name):
        return getattr(self._conn, name)




# Tools
# Tool-1
search_tool = DuckDuckGoSearchRun(region="us-en")
# Define the logic as a standard function
# async def run_search_async(query: str) -> str:
#     """Run a DuckDuckGo search asynchronously."""
#     return await asyncio.to_thread(search_tool.run, query)

# # Create the tool
# search_tool_async = StructuredTool.from_function(
#     func=search_tool.run,
#     coroutine=run_search_async, # Pass the named function here
#     name=search_tool.name,
#     description=search_tool.description
# )


@tool
async def search_tool_async(query: str) -> str:
    """
    Search the web for information using DuckDuckGo. 
    Useful for answering questions about current events or finding general information.
    """
    # This keeps the graph from freezing while waiting for the web response
    return await asyncio.to_thread(search_tool.run, query)

# Inject metadata to match the original tool exactly
search_tool_async.name = search_tool.name
search_tool_async.description = search_tool.description

# Tool-2
# MCP client for local FastMCP server
client = MultiServerMCPClient(
    {
        "arith": {
            "transport": "stdio",
            "command": "C:/Users/Ashish/Desktop/LANGGRAPH-Project/newenv310/Scripts/python.exe", 
            "args": ["C:/Users/Ashish/Desktop/LANGGRAPH-Project/MCP_server_calculator.py"],
        },
        "expense": {
            "transport": "stdio",
            "command": "C:/Users/Ashish/Desktop/LANGGRAPH-Project/newenv310/Scripts/python.exe",
            "args": ["C:/Users/Ashish/Desktop/LANGGRAPH-Project/MCP_server_expense.py"],
        }
    }
)

# Tool-3
@tool
async def get_stock_price(symbol: str) -> dict:
    """
    Fetch latest stock price for a given symbol (e.g. 'AAPL', 'TSLA')
    using Alpha Vantage with API key in the URL.
    """
    url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey=FHHVTI78I9PRGT3"
    async with httpx.AsyncClient() as client:
        r = await client.get(url)
        return r.json()

# Tool-4
# RAG tool
# Initialize with your specific PDF path here
pdf_manager = RAGPDF("Introduction to Machine Learning with Python.pdf")
sync_rag_tool = pdf_manager.get_tool()

# @tool
# async def rag_tool_async(query:str) ->str:
#     return await asyncio.to_thread(sync_rag_tool.invoke,query)

rag_tool_async = StructuredTool.from_function(
    func = sync_rag_tool.invoke,  # The original logic
    coroutine=lambda q:asyncio.to_thread(sync_rag_tool.invoke,q),  # The async logic
    name = sync_rag_tool.name, # Inherent name
    description=sync_rag_tool.description # inherent docstring
)

load_dotenv()

model = ChatOpenAI(model = "gpt-4o-mini")

# 1. Gather all local tools
tools = [search_tool_async, get_stock_price, rag_tool_async]

async def _init_mcp_and_fetch_tools():
    """Initializes and reads out tools securely inside the persistent background loop."""
    return await client.get_tools()

# 2. Resolve MCP tools safely using the permanent background loop thread
try:
    print("Connecting to MCP servers and fetching tools...")

    fetched_mcp_tools = asyncio.run(
        _init_mcp_and_fetch_tools()
    )

    tools.extend(fetched_mcp_tools)

    print(
        f"Successfully loaded "
        f"{len(fetched_mcp_tools)} tools from MCP server."
    )

except Exception as e:
    print(f"Warning: Failed to fetch MCP tools at startup: {e}")

# 3. Permanently bind the unified toolset to your LLM globally at the top level
llm_with_tools = model.bind_tools(tools)
print("Globally bound tools:", [t.name for t in tools])

# Creates database in same folder as code
#GLOBAL_CONN = sqlite3.connect(database='chatbot.db', check_same_thread=False, isolation_level=None)

DB_PATH = "chatbot.db"

# Initialize database
async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL;")
        await db.execute("""
            CREATE TABLE IF NOT EXISTS thread_meta (
                thread_id TEXT PRIMARY KEY,
                title TEXT
            )"""
        )
        await db.execute("""
        CREATE TABLE IF NOT EXISTS tool_metrics_meta (
            thread_id TEXT,
            message_id TEXT,
            tool_name TEXT,
            execution_time REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP            
                        
        )""")
        await db.commit()
    

# State creation
class ChatState(TypedDict):
    # Reducer function add - To append
    messages: Annotated[list[BaseMessage],add_messages]


async def chat_node(state: ChatState):

    messages = state['messages']

    response = await llm_with_tools.ainvoke(messages)

    return {'messages': [response]}


tool_node = ToolNode(tools)

graph_builder = StateGraph(ChatState)

graph_builder.add_node("chat_node", chat_node)

graph_builder.add_node("tools", tool_node)

graph_builder.add_edge(START, "chat_node")

graph_builder.add_conditional_edges(
    "chat_node",
    tools_condition
)

graph_builder.add_edge("tools", "chat_node")







import asyncio

class AsyncGraphManager:

    def __init__(self, db_path):

        self.DB_PATH = db_path

        self.graph = None

        self.conn = None

        self.checkpointer = None

    async def initialize(self):

        # Create persistent async sqlite connection
        raw_conn = await aiosqlite.connect(self.DB_PATH)

        # Wrap connection safely
        self.conn = SafeAioSqliteConnection(raw_conn)

        # Create async checkpointer
        self.checkpointer = AsyncSqliteSaver(self.conn)

        # Compile graph once
        self.graph = graph_builder.compile(
            checkpointer=self.checkpointer
        )

    async def aget_state(self, config):

        return await self.graph.aget_state(
            config=config
        )

    async def aupdate_state(self, config, values):

        return await self.graph.aupdate_state(
            config=config,
            values=values
        )

    async def astream(
        self,
        input_data,
        config,
        stream_mode='messages'
    ):

        async for chunk in self.graph.astream(
            input_data,
            config=config,
            stream_mode=stream_mode
        ):
            yield chunk

    async def close(self):

        if self.conn:

            await self.conn.close()
chatbot = AsyncGraphManager(DB_PATH)


async def startup():

    await init_db()

    await chatbot.initialize()

asyncio.run(startup())

# Ensure your global connection exists if the frontend references it for legacy reasons
GLOBAL_CONN = sqlite3.connect(DB_PATH, check_same_thread=False)

async def retrieve_all_threads():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT thread_id,title FROM thread_meta") as cursor:
            rows = await cursor.fetchall()
            return [(str(row[0]),row[1]) for row in rows]
    

